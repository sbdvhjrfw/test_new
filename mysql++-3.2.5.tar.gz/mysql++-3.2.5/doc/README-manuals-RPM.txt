For more information about MySQL++, see its home page:

	http://tangentsoft.net/mysql++/

See the LICENSE file in this directory for the library's license.
