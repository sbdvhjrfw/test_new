var searchData=
[
  ['what_939',['what',['../classmysqlpp_1_1Exception.html#af59280d82dba0627192a26cdcf53ba96',1,'mysqlpp::Exception']]],
  ['what_5foption_940',['what_option',['../classmysqlpp_1_1BadOption.html#a7a1be48b23c7148e553110985ec680ff',1,'mysqlpp::BadOption']]],
  ['windowsnamedpipeconnection_941',['WindowsNamedPipeConnection',['../classmysqlpp_1_1WindowsNamedPipeConnection.html#a8f144565e1f5c82783b923529c791944',1,'mysqlpp::WindowsNamedPipeConnection::WindowsNamedPipeConnection()'],['../classmysqlpp_1_1WindowsNamedPipeConnection.html#aaa7a945b918efe54b095d52a472153fc',1,'mysqlpp::WindowsNamedPipeConnection::WindowsNamedPipeConnection(const char *db, const char *user=0, const char *password=0)'],['../classmysqlpp_1_1WindowsNamedPipeConnection.html#ac9fe1d6a34624327ed811ad9a4e960e6',1,'mysqlpp::WindowsNamedPipeConnection::WindowsNamedPipeConnection(const WindowsNamedPipeConnection &amp;other)']]]
];
