var searchData=
[
  ['nr_5fcode_1032',['nr_code',['../classmysqlpp_1_1DBDriver.html#a0275cada4dbb299404e02bffc113adda',1,'mysqlpp::DBDriver']]]
];
