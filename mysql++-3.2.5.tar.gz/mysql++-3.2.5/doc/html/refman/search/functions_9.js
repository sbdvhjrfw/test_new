var searchData=
[
  ['kill_753',['kill',['../classmysqlpp_1_1Connection.html#a8d934ece7ac0fdc7341022f7af75225f',1,'mysqlpp::Connection::kill()'],['../classmysqlpp_1_1DBDriver.html#abef4b00d04388bd13a410e378b06950a',1,'mysqlpp::DBDriver::kill()']]]
];
